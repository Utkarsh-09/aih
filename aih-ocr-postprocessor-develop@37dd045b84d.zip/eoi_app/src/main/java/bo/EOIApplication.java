package bo;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EOIApplication {

    String policyNumber;
    String employeeID ;
    String employeeSSN;
    String employeeFirstName;
    String employeeMiddleName;
    String employeeLastName;
    String employeeDateOfBirth;
    String employeeAddressLine1;
    String employeeAddressLine2;
    String employeeAddressLine3;
    String employeeAddressCity;
    String employeeAddressStateCode;
    String employeeAddressPostalCode;
    String employeeWorkPhoneNumber;
    String employeeMobilePhoneNumber;
    String employeeEmailAddress;
    String employeeGenderCode;
    String locationCode;
    Boolean employeeApplicantFlag;
    Boolean spouseApplicantFlag;
    Boolean dependentApplicantFlag;
    Integer dependentApplicantCount;



}
