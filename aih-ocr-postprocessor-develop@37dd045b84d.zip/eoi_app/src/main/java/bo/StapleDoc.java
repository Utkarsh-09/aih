package bo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.util.JSONPObject;
import lombok.Data;
import java.util.ArrayList;
import java.util.HashMap;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StapleDoc {

    String fileName;
    String status;
    String language;
    String docType;
    HashMap<String , JsonNode> json;
}
