package bo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import java.util.ArrayList;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StapleElements {

     ArrayList<Match> matches;
     String UICategory ;
     String UIName ;
     String UIType;


}
