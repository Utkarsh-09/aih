package bo;

import lombok.Data;
import java.util.ArrayList;

@Data
public class Match {
    String match;
    String matchmulti;
    ArrayList value ;
    ArrayList keyword;
    Integer page ;
    Integer score ;
}
