package bo;

import lombok.Data;

@Data
public class StapleResponse {

   StapleDoc getDocumentJSONDataAndImage ;

}
