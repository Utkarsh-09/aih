package bo;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class StapleDoccument {

    Integer id;
    String fileName;
    String status;

}
