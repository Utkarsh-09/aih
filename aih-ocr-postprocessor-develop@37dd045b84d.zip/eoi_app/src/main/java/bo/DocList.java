package bo;

import lombok.Data;

@Data
public class DocList {

    GetDocumentsByStatus  getDocumentsByStatus;
}
