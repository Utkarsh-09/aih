import bo.EOIApplication;
import bo.StapleDoccument;
import bo.StapleElements;
import bo.StapleResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.Response;
import org.awaitility.Awaitility;
import util.EoIService;
import util.HttpClient;
import util.StapleService;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;


public class TestClass {

    public static void main(String[] args) {

        try {
            Awaitility.with()
                    .pollInterval(1, TimeUnit.MINUTES)
                    .atMost(15, TimeUnit.MINUTES)
                    .await()
                    .until(() -> (true == processDocsInQueue()));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static boolean processDocsInQueue() throws IOException, URISyntaxException, ParseException {

        System.out.println("Processing Queue");

        EoIService eoIService = new EoIService();
        StapleService stapleService = new StapleService();

        ArrayList<StapleDoccument> dosList = stapleService.getCompletedDocuments(1325);


        for(StapleDoccument doc : dosList) {

            if("COMPLETED".equalsIgnoreCase(doc.getStatus())){
                HashMap<String, StapleElements> jsonElements =  stapleService.getDocumentElement(doc.getId());

                System.out.println(eoIService.createEoIApplicationRequest(jsonElements).toString());
                eoIService.createApplication(eoIService.createEoIApplicationRequest(jsonElements));
                return true;
            }

        }
        return false;


    }
}
