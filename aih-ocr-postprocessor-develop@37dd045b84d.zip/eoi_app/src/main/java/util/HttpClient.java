package util;

import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class HttpClient {

    OkHttpClient client = new OkHttpClient.Builder()
            .readTimeout(1000, TimeUnit.MILLISECONDS)
            .writeTimeout(1000, TimeUnit.MILLISECONDS)
            .build();
    ObjectMapper objectMapper = new ObjectMapper();

    public Response invokePost(String url , Object requestObj , HashMap<String, String> queryParams , HashMap<String, String> headers) throws URISyntaxException, IOException {


        String requestBody = objectMapper.writeValueAsString(requestObj);

        RequestBody body = RequestBody.create(MediaType.parse("application/json"), requestBody);

        Request.Builder reqBuilder = new Request.Builder().url(url);
        if(headers != null) {
            for (Map.Entry<String, String> header : headers.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }

        //3. Create HTTP request
        Request request = reqBuilder.post(body).build();

        System.out.println(objectMapper.writeValueAsString(requestBody));
        System.out.println(objectMapper.writeValueAsString(body.contentLength()));
        //4. Synchronous call to the REST API
        Response response = client.newCall(request).execute();

        return response;
    }


    public Response get(String url , HashMap<String, String> queryParams , HashMap<String, String> headers ) throws IOException {

        HttpUrl.Builder urlBuilder  = HttpUrl.parse(url).newBuilder();
        if(queryParams != null ) {
            for (Map.Entry<String, String> queryParam : queryParams.entrySet()) {
                urlBuilder.addQueryParameter(queryParam.getKey(), queryParam.getValue());
            }

            url = urlBuilder.build().toString();
        }
        Request.Builder reqBuilder = new Request.Builder().url(url);

        if(headers != null) {
            for (Map.Entry<String, String> header : headers.entrySet()) {
                reqBuilder.addHeader(header.getKey(), header.getValue());
            }
        }

        Request request =   reqBuilder.build();

        Response  response = client.newCall(request).execute();

        return response;

    }
}
