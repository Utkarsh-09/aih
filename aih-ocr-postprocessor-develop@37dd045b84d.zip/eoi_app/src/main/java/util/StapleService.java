package util;

import bo.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.Response;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class StapleService {

    HttpClient client = new HttpClient();
    HashMap<String,String> headers = new HashMap<String,String>();
    ArrayList<String> filterKey = new ArrayList<String> ( Arrays.asList("BigBoxes","DocSize","LineItems","LineItems_standardHeader","MiniBoxes","SmallBoxes","TableDetected","Tables","num_pages","telescope_constellation_id","telescope_model_id","telescope_template_id"));
    ObjectMapper objectMapper = new ObjectMapper();

    public StapleService(){
        headers.put("x-api-key","099a6bf44fb529b2af184600c722a2701153bc67616cddecbfa65fccdf63a218") ;
        headers.put("Authorization","Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjQ0OSwiaWRlbnRpdHkiOiI0NDkiLCJpYXQiOjE2NjY2MDUzMjUsImV4cCI6MTY2NzIxMDEyNX0.M_cuUMlyV0q-OBVAqaNeDgnHgYsDr95_E9w7An0yDxc") ;

    }
    public ArrayList<StapleDoccument> getCompletedDocuments(Integer queueId) throws IOException, URISyntaxException {


        DocList docs = null;
        HashMap<String,Object> filter = new HashMap<String, Object>();
        filter.put("qid",queueId);
        filter.put("status","COMPLETED");

        HashMap<String,HashMap<String,Object>> request = new HashMap<String,HashMap<String,Object>>();
        request.put("filter", filter);

        HttpClient client = new HttpClient();
        Response response = client.invokePost("http://localhost/api/v1/documents", request, null, headers);

        if(response.isSuccessful()) {
            docs = objectMapper.readValue(response.body().string(),DocList.class);
        }

        return docs.getGetDocumentsByStatus().getData();

    }

    public HashMap<String, StapleElements> getDocumentElement(Integer docId) throws IOException {

        Response resp =  client.get("http://localhost/api/v1/documents/"+docId ,null , headers);

        StapleResponse entity = objectMapper.readValue(resp.body().string(), StapleResponse.class);

        HashMap<String, JsonNode> jsonList = entity.getGetDocumentJSONDataAndImage().getJson();
        HashMap<String, StapleElements> jsonElements = new HashMap<String, StapleElements>() ;

        for (Map.Entry<String, JsonNode> jsonNode : jsonList.entrySet()) {
            if(!filterKey.contains(jsonNode.getKey())){

                StapleElements element = objectMapper.treeToValue(jsonNode.getValue(), StapleElements.class);
                jsonElements.put(jsonNode.getKey() , element);
            }

        }

        return jsonElements;
    }

    String getValueOfElement(StapleElements element){

        if(element !=null) {
        ArrayList<Match> ma = element.getMatches();
        if(ma != null && ma.size() >0){
            Match mat =  ma.get(0);

            return mat.getMatch() ;
        }}
        return "";

    }
}
