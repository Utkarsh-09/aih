package util;

import bo.EOIApplication;
import bo.StapleElements;
import okhttp3.Response;

import javax.swing.text.DateFormatter;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class EoIService {

    StapleService stapleService = new StapleService();

    public EOIApplication createEoIApplicationRequest(HashMap<String, StapleElements> jsonElements) throws ParseException {

        EOIApplication.EOIApplicationBuilder builder =  EOIApplication.builder();

        builder.policyNumber("926925")
                .employeeSSN(stapleService.getValueOfElement(jsonElements.get("ssn")))
                .employeeID(stapleService.getValueOfElement(jsonElements.get("ssn")))
                .employeeFirstName(getName(jsonElements).get("fName"))
                .employeeMiddleName(getName(jsonElements).get("mName"))
                .employeeLastName(getName(jsonElements).get("lName"))
                .employeeDateOfBirth(getDOB(jsonElements))
                .employeeAddressLine1(stapleService.getValueOfElement(jsonElements.get("Address")))
                .employeeAddressPostalCode(stapleService.getValueOfElement(jsonElements.get("ZipCode")))
                .employeeAddressCity(stapleService.getValueOfElement(jsonElements.get("city")))
                .employeeAddressStateCode(stapleService.getValueOfElement(jsonElements.get("state")))
                .employeeWorkPhoneNumber(stapleService.getValueOfElement(jsonElements.get("dayPhoneNumber")))
                .employeeMobilePhoneNumber(stapleService.getValueOfElement(jsonElements.get("dayPhoneNumber")))
                .employeeEmailAddress(stapleService.getValueOfElement(jsonElements.get("email")))
                .employeeGenderCode(getGenderCode(jsonElements))
                .locationCode(getLocationCode(jsonElements))
                .employeeApplicantFlag(true)
                .spouseApplicantFlag(false)
                .dependentApplicantFlag(false)
                .dependentApplicantCount(0);



        return builder.build();

    }

    private String getGenderCode(HashMap<String, StapleElements> jsonElements) {
        String isMale = stapleService.getValueOfElement(jsonElements.get("isMale")) ;
        String isFemale = stapleService.getValueOfElement(jsonElements.get("isFemale")) ;
        String gender = stapleService.getValueOfElement(jsonElements.get("Gender")) ;

        if("true".equalsIgnoreCase(isMale) || "male".equalsIgnoreCase(gender) ){
            return "U" ;
        } else {
            return "U" ;
        }

    }

    private String getDOB(HashMap<String, StapleElements> jsonElements) throws ParseException {

        String dob = stapleService.getValueOfElement(jsonElements.get("dob")) ;
        try{
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat format1 = new SimpleDateFormat("dd/MM/yyyy");

        Date date = format1.parse(dob);

        if(dob !=null && !dob.equalsIgnoreCase("")){
            return dateFormat.format(date);
        }}
        catch(Exception ex) {

        }
        return "1999-07-22";

    }

    private HashMap<String,String> getName(HashMap<String, StapleElements> jsonElements) {
        HashMap<String,String> nameMap = new HashMap<String,String>();
        String name = stapleService.getValueOfElement(jsonElements.get("EmployeeName")) ;
        String fName = stapleService.getValueOfElement(jsonElements.get("firstName")) ;
        String lName = stapleService.getValueOfElement(jsonElements.get("lastName")) ;

        if(!"".equalsIgnoreCase(fName)){
            nameMap.put("fName",fName);

        }
        if(!"".equalsIgnoreCase(lName)){
            nameMap.put("lName",lName);

        }
        if(name !=null && !"".equalsIgnoreCase(name)){
            String[] nameParts =name.split(" ");
            if(nameParts.length >2) {
                nameMap.put("fName", nameParts[0]);
                nameMap.put("mName", nameParts[1]);
                nameMap.put("lName", nameParts[2]);
            } else if(nameParts.length ==2) {
                nameMap.put("fName", nameParts[0]);
                nameMap.put("lName", nameParts[1]);
            } else if (nameParts.length ==1) {
                nameMap.put("fName", nameParts[0]);
            }
        }
        return nameMap;
    }

    private String getLocationCode(HashMap<String, StapleElements> jsonElements) {
        return "001";
    }


    public void createApplication(EOIApplication application) throws IOException, URISyntaxException {
        HttpClient client = new HttpClient();
        Response resp = client.invokePost("http://qar-eoiadminapps.us.sunlife/eoi/restful/eoi/employee/", application, null, null);
        System.out.println(resp.body().string());

    }
}
